#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
flags=(-target i386-linux-gnu -std=c11 -O2 -ffreestanding -fno-builtin -fno-pic -fno-stack-protector -Wall -Wextra -Werror)
clang "${flags[@]}" -c tests/native_grievance_x86.c -o build/native_grievance_x86.o
clang "${flags[@]}" -c src/fhd_npc_ai.c -o build/grievance_core_x86.o
clang "${flags[@]}" -c src/fhd_profession_policy.c -o build/grievance_profession_x86.o
clang "${flags[@]}" -c src/fhd_world.c -o build/world_x86.o
clang "${flags[@]}" -c src/fhd_dialogue.c -o build/dialogue_x86.o
clang "${flags[@]}" -c src/fhd_dialogue_settings.c -o build/dialogue_settings_x86.o
clang "${flags[@]}" -c src/fhd_grievance_rules.c -o build/grievance_rules_x86.o
clang "${flags[@]}" -c tests/fixtures/local_dialogue.c -o build/local_dialogue_x86.o
ld.lld -m elf_i386 -N -o build/native_grievance_x86 build/{native_grievance_x86,grievance_core_x86,grievance_profession_x86}.o build/world_x86.o build/dialogue_x86.o build/dialogue_settings_x86.o build/grievance_rules_x86.o build/local_dialogue_x86.o
if "${FHD_QEMU_I386:-qemu-i386}" build/native_grievance_x86; then
  echo 'x86 witnessed loot cycle passed'
else
  line=$?
  echo "x86 witnessed loot cycle failed at test source line or status $line" >&2
  exit "$line"
fi
